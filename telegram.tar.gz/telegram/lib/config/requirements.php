<?php

return array(
    'php' => array(
        'strict' => true,
        'version' => '>=7.4.0',
    ),
    'app.installer' => [
        'version' => '3.1.0',
        'strict' => true
    ],
);