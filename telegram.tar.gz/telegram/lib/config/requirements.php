<?php

return array(
    'php' => array(
        'strict' => true,
        'version' => '>=7.4.0',
    ),
    'webasyst' => '>= 3.1',
);