<?php

return array (
    '*' => 'frontend/'
    );
