<?php 

class telegramViewHelper extends waAppViewHelper
{

}