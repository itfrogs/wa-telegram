<?php
return array (
  'steelrat/bot' => 'frontend/bot',
);
