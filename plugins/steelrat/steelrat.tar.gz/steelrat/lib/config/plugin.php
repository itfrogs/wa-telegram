<?php
return array (
    'name' => _wp('You can be the Stainless Steel Rat'),
    'img' => 'img/steelrat16.png',
    'version' => '1.0.2',
    'vendor' => '964801',
    'frontend' => true,
    'handlers' =>
        array (
        ),
);
