<?php
/**
 * Created by PhpStorm.
 * User: snark | itfrogs.ru
 * Date: 4/3/18
 * Time: 1:30 PM
 */

class telegramSteelratPluginBookModel extends waModel
{
    protected $table = 'telegram_steelrat_book';
}